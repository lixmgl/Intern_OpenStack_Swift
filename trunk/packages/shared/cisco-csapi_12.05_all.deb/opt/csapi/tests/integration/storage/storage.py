# ********************************************************************   
# *        Copyright (c) 2009-2012 Cisco Systems, Inc.   
# *        All rights reserved.   
# ********************************************************************

class ComputeNodes(object):
    def get_junk(self):
        a=1
        b=1
        if a == b:
            return True
        else:
            return False

    def set_junk(self):
        a=1
        b=1
        if a == b:
            return True
        else:
            return False
    def close(self):
        return True
